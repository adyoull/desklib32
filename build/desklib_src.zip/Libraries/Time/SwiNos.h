
XOS_Bit                            EQU &020000

SWI_OS_Word                        EQU &000007

SWI_OS_ReadMonotonicTime           EQU &000042
SWI_OS_ConvertStandardDateAndTime  EQU &0000C0
SWI_OS_ConvertDateAndTime          EQU &0000C1

SWI_Territory_ConvertTimeToOrdinals     EQU &04304F
SWI_Territory_ConvertTimeToUTCOrdinals  EQU &043049

         END
